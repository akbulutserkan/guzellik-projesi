

'use server';

import { db } from "@/lib/firebaseAdmin";
import { Timestamp, Transaction, FieldValue } from 'firebase-admin/firestore';
import { revalidatePath } from "next/cache";
import { getCustomersAction, performAddCustomerAction, type Customer } from "../musteriler/actions";
import { getPersonelAction, type Personel } from "../personeller/actions";
import { getServicesAction, type Service } from "../hizmetler/actions";
import { getGroupedPackagesAction, type Package, getCustomerPackagesAction as baseGetCustomerPackagesAction, type CustomerPackageInfo } from "../paketler/actions";
import { decreaseStockForSale, getProductsAction, increaseStockAfterSaleCancellation, type Product as BaseProduct } from "../urunler/actions";
import { Product as SaleableProduct, Sale } from "../urun-satislar/actions";
import { PaymentType } from "../kasa/actions";
import { startOfDay, endOfDay, isSameDay } from 'date-fns';


export interface Appointment {
    id: string;
    groupId: string;
    customerId: string;
    customerName: string;
    personnelId: string;
    personnelName: string;
    serviceId: string; // Hizmet veya Paket ID'si
    serviceName: string;
    price: number; // The actual price for this specific appointment
    isPackage: boolean; // Bu bir paket randevusu mu?
    isPackageSession: boolean; // Bu, bir paketten düşülen tek bir seans mı?
    packageSaleId?: string; // Hangi paket satışından düşüldü?
    start: Date;
    end: Date;
    notes?: string;
    createdAt: Date;
    status: "active" | "completed" | "cancelled"; // active, completed or cancelled
}

export interface CalendarPageData {
    appointments: Appointment[];
    customers: Customer[];
    personnel: Personel[];
    services: Service[];
    packages: Package[];
    products: SaleableProduct[];
}

// Randevuları Çek
export async function getAppointmentsAction(): Promise<Appointment[]> {
    if (!db) {
      console.error("[getAppointmentsAction LOG] Firestore veritabanı bağlantısı mevcut değil.");
      return [];
    }
    try {
      const snapshot = await db.collection("appointments").orderBy("start", "asc").get();
      return snapshot.docs.map(doc => {
        const data = doc.data();
        
        const startTimestamp = data.start as Timestamp;
        const endTimestamp = data.end as Timestamp;
        
        return {
          id: doc.id,
          ...data,
          start: startTimestamp.toDate(),
          end: endTimestamp.toDate(),
          isPackageSession: data.isPackageSession || false,
          createdAt: (data.createdAt as Timestamp).toDate(),
        } as Appointment;
      });
    } catch (error: any) {
      console.error("[getAppointmentsAction LOG] Randevular çekilirken HATA:", error.message);
      return [];
    }
}

// Takvim sayfası için gerekli tüm verileri tek seferde çek
export async function getCalendarPageData(): Promise<CalendarPageData> {
    try {
        const [appointments, customers, personnel, services, packagesByCategory, products] = await Promise.all([
            getAppointmentsAction(),
            getCustomersAction(),
            getPersonelAction(),
            getServicesAction(),
            getGroupedPackagesAction(),
            getProductsAction()
        ]);
        
        // getProductsAction'dan dönen SaleableProduct'ları BaseProduct'a dönüştür
        const saleableProducts: SaleableProduct[] = products.map(p => ({
            id: p.id,
            name: p.name,
            stock: p.stock,
            sellingPrice: p.latestSellingPrice || 0,
            createdAt: p.createdAt
        }));
        
        const packages = Object.values(packagesByCategory).flatMap(cat => cat.packages);

        return { appointments, customers, personnel, services, packages, products: saleableProducts };
    } catch (error: any) {
        console.error("[getCalendarPageData LOG] Fonksiyon sırasında KRİTİK HATA:", error.message);
        // Hata durumunda boş bir nesne döndürerek uygulamanın çökmesini engelle
        return { appointments: [], customers: [], personnel: [], services: [], packages: [], products: [] };
    }
}

// Bir müşterinin aktif paketlerini ve kalan seanslarını çek
export async function getCustomerPackagesAction(customerId: string): Promise<CustomerPackageInfo[]> {
    return baseGetCustomerPackagesAction(customerId);
}


// Birden çok randevuyu tek bir grup olarak ekle
export async function performAddAppointmentAction(formData: FormData) {
    'use server';
    const customerId = formData.get("customerId") as string;
    const dateTimeStr = formData.get("dateTime") as string;
    const notes = formData.get("notes") as string || "";

    const personnelIds = formData.getAll("personnelIds") as string[];
    const serviceOrPackageIds = formData.getAll("serviceOrPackageIds") as string[];
    const prices = formData.getAll("prices").map(p => parseFloat(p as string));
    const isPackageSessionFlags = formData.getAll("isPackageSession").map(f => f === 'true');
    const packageSaleIds = formData.getAll("packageSaleIds") as string[];


    if (!customerId || personnelIds.length === 0 || !dateTimeStr) {
        return { success: false, message: "Müşteri, en az bir hizmet ve tarih/saat zorunludur." };
    }
     if (personnelIds.length !== serviceOrPackageIds.length || personnelIds.length !== prices.length) {
        return { success: false, message: "Hizmet satırı bilgileri eşleşmiyor." };
    }

    if (!db) return { success: false, message: "Veritabanı bağlantı hatası." };
    
    try {
        const customerDoc = await db.collection("customers").doc(customerId).get();
        if (!customerDoc.exists) {
            const newCustomerResult = await performAddCustomerAction(formData);
            if (!newCustomerResult.success || !newCustomerResult.newCustomer) {
                return { success: false, message: "Yeni müşteri oluşturulamadı veya müşteri bilgisi alınamadı." };
            }
            formData.set("customerId", newCustomerResult.newCustomer.id);
        }
        
        const finalCustomerId = formData.get("customerId") as string;
        const finalCustomerDoc = await db.collection("customers").doc(finalCustomerId).get();
        if (!finalCustomerDoc.exists) return { success: false, message: "Müşteri bulunamadı." };

        const customerName = finalCustomerDoc.data()?.fullName;

        // Tüm personelleri ve hizmetleri/paketleri önceden çek
        const allPersonnel = await getPersonelAction();
        const allServices = await getServicesAction();
        const allPackages = Object.values(await getGroupedPackagesAction()).flatMap(cat => cat.packages);
        
        const appointmentDate = new Date(dateTimeStr);

        // Müşterinin o gün için mevcut randevularını kontrol et
        const allCustomerAppointmentsSnap = await db.collection("appointments")
            .where("customerId", "==", finalCustomerId)
            .get();

        const appointmentsOnDate = allCustomerAppointmentsSnap.docs
            .map(doc => ({ ...doc.data(), id: doc.id, start: (doc.data().start as Timestamp).toDate(), end: (doc.data().end as Timestamp).toDate() } as Appointment))
            .filter(app => isSameDay(app.start, appointmentDate));

        
        let appointmentGroupId: string;
        let currentStartTime = new Date(dateTimeStr); // Always start from the user-selected time.

        if (appointmentsOnDate.length > 0) {
            // Mevcut bir randevu varsa, onun groupId'sini kullan.
            appointmentGroupId = appointmentsOnDate[0].groupId;
        } else {
            // Yeni randevu, yeni groupId
            appointmentGroupId = db.collection("appointments").doc().id;
        }

        const batch = db.batch();

        for (let i = 0; i < personnelIds.length; i++) {
            const personnelId = personnelIds[i];
            const serviceOrPackageId = serviceOrPackageIds[i];
            const price = prices[i];
            const isPackageSession = isPackageSessionFlags[i] || false;
            const packageSaleId = packageSaleIds[i] || "";

            const personnel = allPersonnel.find(p => p.id === personnelId);
            if (!personnel) throw new Error(`Personel bulunamadı: ${personnelId}`);

            let serviceName = "";
            let duration = 0;
            let isPackage = false; // Bu, hizmetin bir "Paket Satışı" mı yoksa tek hizmet mi olduğunu belirtir

            const service = allServices.find(s => s.id === serviceOrPackageId);
            const pkg = allPackages.find(p => p.id === serviceOrPackageId);

            if (service) {
                serviceName = service.name;
                duration = service.duration;
            } else if (pkg) {
                serviceName = pkg.name;
                duration = pkg.serviceIds.reduce((acc, sid) => acc + (allServices.find(s => s.id === sid)?.duration || 0), 0) || 60;
                isPackage = true;
            } else {
                // Eğer müşteri paketinden gelen bir hizmetse, ismini ve süresini bul
                const serviceFromPackage = allServices.find(s => s.id === serviceOrPackageId);
                if (isPackageSession && serviceFromPackage) {
                    serviceName = serviceFromPackage.name;
                    duration = serviceFromPackage.duration;
                } else {
                    throw new Error(`Hizmet veya paket bulunamadı: ${serviceOrPackageId}`);
                }
            }

            if (duration <= 0) throw new Error(`Hizmetin süresi geçersiz: ${serviceName}`);
            if (isNaN(price) || price < 0) throw new Error("Geçersiz fiyat değeri.");
            
            const startDate = currentStartTime;
            const endDate = new Date(startDate.getTime() + duration * 60000);
            
            const appointmentData: any = {
                groupId: appointmentGroupId,
                customerId: finalCustomerId,
                customerName,
                personnelId,
                personnelName: personnel.fullName,
                serviceId: serviceOrPackageId,
                serviceName,
                price: isPackageSession ? 0 : price, // Paket seansıysa fiyat 0'dır
                isPackage,
                isPackageSession,
                start: Timestamp.fromDate(startDate),
                end: Timestamp.fromDate(endDate),
                notes,
                createdAt: FieldValue.serverTimestamp(),
                status: "active",
            };

            if (isPackageSession && packageSaleId) {
                appointmentData.packageSaleId = packageSaleId;
            }

            const newAppointmentRef = db.collection("appointments").doc();
            batch.set(newAppointmentRef, appointmentData);

            currentStartTime = endDate;
        }

        await batch.commit();
        revalidatePath("/takvim");

        return { success: true, message: `${personnelIds.length} adet randevu başarıyla oluşturuldu.` };

    } catch (error: any) {
        console.error("Randevu kaydetme hatası:", error);
        return { success: false, message: error.message || "Randevu oluşturulurken bir sunucu hatası oluştu." };
    }
}


export async function performUpdateAppointmentAction({ event, start, end, newPersonnelId }: { event: Appointment; start: Date; end: Date; newPersonnelId?: string | undefined }) {
    'use server';
    if (!event || !start || !end) {
        return { success: false, message: "Gerekli bilgiler eksik." };
    }
    if (!db) return { success: false, message: "Veritabanı bağlantı hatası." };

    try {
        const appointmentRef = db.collection("appointments").doc(event.id);
        const appointmentDoc = await appointmentRef.get();
        if (!appointmentDoc.exists) {
            throw new Error("Güncellenecek randevu bulunamadı.");
        }

        const updateData: { [key: string]: any } = {
            start: Timestamp.fromDate(start),
            end: Timestamp.fromDate(end),
        };
        
        if (newPersonnelId && newPersonnelId !== event.personnelId) {
             const allPersonnel = await getPersonelAction();
             const targetPersonnel = allPersonnel.find(p => p.id === newPersonnelId);
             if (targetPersonnel) {
                updateData.personnelId = targetPersonnel.id;
                updateData.personnelName = targetPersonnel.fullName;
             }
        }
        
        await appointmentRef.update(updateData);
        
        revalidatePath("/takvim");
        return { success: true, message: "Randevu başarıyla güncellendi." };

    } catch (error: any) {
        console.error("Randevu güncelleme hatası:", error);
        return { success: false, message: error.message || "Randevu güncellenirken bir sunucu hatası oluştu." };
    }
}


// Randevu Grubunu ve Satışları Güncelle
export async function performFullUpdateAppointmentAction(formData: FormData) {
    'use server';
    const groupId = formData.get("groupId") as string;
    const customerId = formData.get("customerId") as string;
    const dateTimeStr = formData.get("dateTime") as string;
    const notes = formData.get("notes") as string || "";
    const allGroupIdsToDelete = (formData.get("allGroupIdsToDelete") as string).split(',');
    const isDurationChanged = formData.get("isDurationChanged") === 'true';

    const personnelIds = formData.getAll("personnelIds") as string[];
    const serviceOrPackageIds = formData.getAll("serviceOrPackageIds") as string[];
    const prices = formData.getAll("prices").map(p => parseFloat(p as string));
    const isPackageSessionFlags = formData.getAll("isPackageSession").map(f => f === 'true');
    const packageSaleIds = formData.getAll("packageSaleIds") as string[];
    
    const soldProductIds = formData.getAll("soldProductIds") as string[];
    const soldQuantities = formData.getAll("soldQuantities").map(q => parseInt(q as string, 10));
    const soldTotalAmounts = formData.getAll("soldTotalAmounts").map(p => parseFloat(p as string));
    const soldPersonnelIds = formData.getAll("soldPersonnelIds") as string[];
    
    if (!groupId || !customerId || !dateTimeStr || !allGroupIdsToDelete.length) {
        return { success: false, message: "Grup ID, Müşteri, Tarih ve Saat zorunludur." };
    }
    if (personnelIds.some(p => !p) || serviceOrPackageIds.some(s => !s) || prices.some(p => isNaN(p))) {
        return { success: false, message: "Lütfen tüm hizmet satırlarındaki alanları doldurun." };
    }
    if (!db) return { success: false, message: "Veritabanı bağlantı hatası." };
    
   
    try {
        const allPersonnelData = await getPersonelAction();
        const allServices = await getServicesAction();
        const allPackages = Object.values(await getGroupedPackagesAction()).flatMap(cat => cat.packages);
        const allProductsData = await getProductsAction();

        await db.runTransaction(async (transaction) => {
            const customerDocSnap = await transaction.get(db.collection("customers").doc(customerId));
            if (!customerDocSnap.exists) throw new Error("Müşteri bulunamadı.");

            const oldAppointmentsQuery = db.collection("appointments").where("groupId", "in", allGroupIdsToDelete);
            const oldAppointmentsSnap = await transaction.get(oldAppointmentsQuery);

            const oldSalesQuery = db.collection("sales").where("appointmentGroupId", "in", allGroupIdsToDelete);
            const oldSalesSnap = await transaction.get(oldSalesQuery);
            
            for (const doc of oldSalesSnap.docs) {
                const oldSaleData = doc.data();
                await increaseStockAfterSaleCancellation(oldSaleData.productId, oldSaleData.quantity, transaction);
                transaction.delete(doc.ref);
            }

            const originalAppointments = oldAppointmentsSnap.docs.map(doc => {
                const data = doc.data();
                return {
                    ...data,
                    start: (data.start as Timestamp).toDate(),
                    end: (data.end as Timestamp).toDate()
                } as Appointment;
            }).sort((a,b) => (a.start as Date).getTime() - (b.start as Date).getTime());

            const totalOriginalDuration = originalAppointments.length > 0 ? (originalAppointments[originalAppointments.length - 1].end as Date).getTime() - (originalAppointments[0].start as Date).getTime() : 0;

            oldAppointmentsSnap.docs.forEach(doc => transaction.delete(doc.ref));

            const customerName = customerDocSnap.data()?.fullName;
            let currentStartTime = new Date(dateTimeStr);
            
            for (let i = 0; i < personnelIds.length; i++) {
                const personnelId = personnelIds[i];
                const serviceOrPackageId = serviceOrPackageIds[i];
                const price = prices[i];
                const isPackageSession = isPackageSessionFlags[i] || false;
                const packageSaleId = packageSaleIds[i] || "";
                if (!personnelId || !serviceOrPackageId) continue;

                const personnel = allPersonnelData.find(p => p.id === personnelId);
                if (!personnel) throw new Error(`Personel bulunamadı: ${personnelId}`);

                let serviceName = "";
                let duration = 0;
                let isPackage = false;

                const service = allServices.find(s => s.id === serviceOrPackageId);
                const pkg = allPackages.find(p => p.id === serviceOrPackageId);

                if (service) {
                    serviceName = service.name;
                    duration = service.duration;
                } else if (pkg) {
                    serviceName = pkg.name;
                    duration = pkg.serviceIds.reduce((acc, sid) => acc + (allServices.find(s => s.id === sid)?.duration || 0), 0) || 60;
                    isPackage = true;
                } else {
                     const serviceFromPackage = allServices.find(s => s.id === serviceOrPackageId);
                     if (isPackageSession && serviceFromPackage) {
                         serviceName = serviceFromPackage.name;
                         duration = serviceFromPackage.duration;
                     } else {
                         throw new Error(`Hizmet veya paket bulunamadı: ${serviceOrPackageId}`);
                     }
                }

                const startDate = currentStartTime;
                const endDate = isDurationChanged ? new Date(startDate.getTime() + duration * 60000) : new Date(new Date(dateTimeStr).getTime() + totalOriginalDuration);
                
                if (isDurationChanged) {
                    currentStartTime = endDate;
                }

                const appointmentData: any = {
                    groupId, customerId, customerName, personnelId, personnelName: personnel.fullName,
                    serviceId: serviceOrPackageId, serviceName, price: isPackageSession ? 0 : price, isPackage, isPackageSession,
                    start: Timestamp.fromDate(startDate), 
                    end: Timestamp.fromDate(endDate),
                    notes, createdAt: FieldValue.serverTimestamp(), status: "active",
                };
                if(isPackageSession && packageSaleId) {
                    appointmentData.packageSaleId = packageSaleId;
                }
                transaction.set(db.collection("appointments").doc(), appointmentData);
            }
            
            if (soldProductIds.length > 0) {
                for (let i = 0; i < soldProductIds.length; i++) {
                    const productId = soldProductIds[i];
                    const quantity = soldQuantities[i];
                    const totalAmount = soldTotalAmounts[i];
                    const salePersonnelId = soldPersonnelIds[i];

                    if (!productId || !salePersonnelId || !quantity || quantity <= 0) continue;
                    
                    const salePersonnel = allPersonnelData.find(p => p.id === salePersonnelId);
                    const productData = allProductsData.find(p => p.id === productId);

                    if (!salePersonnel || !productData) continue;

                    await decreaseStockForSale(productId, quantity, transaction);
                    
                    const saleData = {
                        productId, productName: productData.name, quantity, totalAmount,
                        customerId, customerName, personnelId: salePersonnel.id,
                        personnelName: salePersonnel.fullName, saleDate: Timestamp.now(),
                        appointmentGroupId: groupId
                    };
                    transaction.set(db.collection("sales").doc(), saleData);
                }
            }
        });

        revalidatePath("/takvim");
        revalidatePath("/urun-satislar");
        revalidatePath("/urunler");
        return { success: true, message: "Randevu başarıyla güncellendi." };

    } catch (error: any) {
        console.error("Randevu güncelleme hatası:", error);
        return { success: false, message: error.message || "Randevu güncellenirken bir sunucu hatası oluştu." };
    }
}


// Randevu Grubunu Sil/İptal Et
export async function performDeleteAppointmentAction(groupId: string) {
    'use server';
    if (!groupId) return { success: false, message: "Randevu Grup ID'si gerekli." };
    if (!db) return { success: false, message: "Veritabanı bağlantı hatası." };
    
    try {
       await db.runTransaction(async (transaction) => {
            const appointmentsQuery = db.collection("appointments").where("groupId", "==", groupId);
            const appointmentsSnap = await transaction.get(appointmentsQuery);
            if (appointmentsSnap.empty) return; 

            const salesQuery = db.collection("sales").where("appointmentGroupId", "==", groupId);
            const salesSnap = await transaction.get(salesQuery);

            if (!salesSnap.empty) {
                for (const doc of salesSnap.docs) {
                    const saleData = doc.data();
                    if (saleData) {
                        await increaseStockAfterSaleCancellation(saleData.productId, saleData.quantity, transaction);
                         transaction.delete(doc.ref);
                    }
                }
            }
            
            appointmentsSnap.docs.forEach(doc => {
                transaction.update(doc.ref, { status: "cancelled" });
            });
        });
        
        revalidatePath("/takvim");
        revalidatePath("/urun-satislar");
        revalidatePath("/urunler");
        revalidatePath("/musteriler");

        return { success: true, message: "Randevu grubu başarıyla iptal edildi." };
    } catch (error: any) {
        console.error("Randevu silme/iptal etme hatası:", error);
        return { success: false, message: error.message || "Randevu iptal edilemedi." };
    }
}

// Sadece tek bir randevu hizmetini sil
export async function deleteSingleAppointmentAction(appointmentId: string) {
    'use server';
    if (!appointmentId) return { success: false, message: "Randevu ID'si gerekli." };
    if (!db) return { success: false, message: "Veritabanı bağlantı hatası." };

    try {
        const appointmentRef = db.collection("appointments").doc(appointmentId);
        await appointmentRef.delete();

        revalidatePath("/takvim");
        return { success: true, message: "Hizmet başarıyla silindi." };
    } catch (error: any) {
        console.error("Tekil randevu silme hatası:", error);
        return { success: false, message: error.message || "Hizmet silinemedi." };
    }
}


export type PaymentMethod = "Nakit" | "Kart" | "Havale/EFT";

interface BasePayload {
    groupId: string;
    customerId: string;
    customerName: string;
}

interface PaymentPayload extends BasePayload {
    totalServiceAmount: number;
    totalProductAmount: number;
    grandTotalAmount: number;
    paymentMethod: PaymentMethod;
    appointmentsInGroup: Appointment[];
}

export async function performPaymentAndUseSessionAction(payload: PaymentPayload) {
    'use server';
    const { groupId, appointmentsInGroup, paymentMethod, ...paymentData } = payload;
    if (!groupId || !paymentMethod) {
        return { success: false, message: "Gerekli ödeme bilgileri eksik." };
    }
    if (!db) return { success: false, message: "Veritabanı bağlantı hatası." };

    try {
        await db.runTransaction(async (transaction) => {
            // Check for already completed appointments
            const appointmentRefs = appointmentsInGroup.map(app => db.collection("appointments").doc(app.id));
            const appointmentDocs = await transaction.getAll(...appointmentRefs);
            
            for (const doc of appointmentDocs) {
                if (!doc.exists) throw new Error("İşlem yapılacak randevulardan biri bulunamadı.");
                if (doc.data()?.status === 'completed') throw new Error("Bu randevu grubu zaten kapatılmış.");
            }

            // 1. Mark package sessions as used by decrementing the counter on the sale
            const packageAppointments = appointmentsInGroup.filter(app => app.isPackageSession);
            for (const app of packageAppointments) {
                if (!app.packageSaleId) continue;
                
                const packageSaleRef = db.collection("packageSales").doc(app.packageSaleId);
                transaction.update(packageSaleRef, {
                    remainingSessions: FieldValue.increment(-1)
                });
            }

            // 2. Create payment transaction if there is a payable amount
            if (paymentData.grandTotalAmount > 0) {
                const paymentRef = db.collection("paymentTransactions").doc(); 
                transaction.set(paymentRef, {
                    ...paymentData,
                    appointmentGroupId: groupId, 
                    paymentMethod: paymentMethod,
                    paymentDate: FieldValue.serverTimestamp(),
                    paymentType: 'appointment' as PaymentType, // THIS IS THE CRITICAL FIX
                });
            }

            // 3. Mark all appointments in the group as completed
            appointmentDocs.forEach(doc => {
                transaction.update(doc.ref, { status: "completed" });
            });
        });

        revalidatePath("/takvim");
        revalidatePath("/kasa");
        revalidatePath("/paket-satislar");
        return { success: true, message: "İşlem başarıyla tamamlandı ve randevu kapatıldı." };

    } catch (error: any) {
        console.error("Karma ödeme ve seans kullanımı hatası:", error);
        return { success: false, message: error.message || "İşlem sırasında bir hata oluştu." };
    }
}


export async function getSalesForAppointmentGroupAction(groupIds: string[]): Promise<Sale[]> {
    if (!db || groupIds.length === 0) {
        return [];
    }
    try {
        const salesSnapshot = await db.collection("sales").where("appointmentGroupId", "in", groupIds).get();
        return salesSnapshot.docs.map(doc => {
            const data = doc.data();
            return {
                id: doc.id,
                ...data,
                saleDate: (data.saleDate as Timestamp).toDate(),
            } as Sale;
        });
    } catch (error) {
        console.error("Grup için satışlar çekilirken hata:", error);
        return [];
    }
}

interface AddServicePayload {
  groupId: string;
  customerId: string;
  personnelId: string;
  serviceId: string;
  price: number;
  isPackage: boolean;
}

export async function addServiceToAppointmentAction(payload: AddServicePayload) {
    'use server';
    const { groupId, customerId, personnelId, serviceId, price, isPackage } = payload;
    if (!db) return { success: false, message: "Veritabanı bağlantı hatası." };
    
    try {
        const [customerDoc, personnelDoc, serviceOrPackageDoc, groupAppointmentsSnap] = await Promise.all([
            db.collection("customers").doc(customerId).get(),
            db.collection("personel").doc(personnelId).get(),
            db.collection(isPackage ? "packages" : "services").doc(serviceId).get(),
            db.collection("appointments").where("groupId", "==", groupId).get()
        ]);

        if (!customerDoc.exists) return { success: false, message: "Müşteri bulunamadı." };
        if (!personnelDoc.exists) return { success: false, message: "Personel bulunamadı." };
        if (!serviceOrPackageDoc.exists) return { success: false, message: "Hizmet veya paket bulunamadı." };

        const allServices = await getServicesAction(); 

        let duration = 0;
        if (isPackage) {
            const pkg = serviceOrPackageDoc.data();
            duration = pkg?.serviceIds.reduce((acc: number, sid: string) => acc + (allServices.find(s => s.id === sid)?.duration || 0), 0) || 60;
        } else {
            duration = serviceOrPackageDoc.data()?.duration || 0;
        }

        if (duration <= 0) return { success: false, message: "Hizmet süresi geçersiz." };
        if (groupAppointmentsSnap.empty) return { success: false, message: "Mevcut randevu grubu bulunamadı." };
        
        const appointmentsInGroup = groupAppointmentsSnap.docs.map(doc => {
            const data = doc.data();
            return {
                id: doc.id, 
                ...data,
                start: (data.start as Timestamp).toDate(),
                end: (data.end as Timestamp).toDate()
            } as Appointment
        });
        
        let lastAppointmentEnd = new Date(0); 
        let lastAppointmentNotes = "";
        
        if (appointmentsInGroup.length > 0) {
            const sortedAppointments = appointmentsInGroup.sort((a,b) => a.end.getTime() - b.end.getTime());
            const lastAppointment = sortedAppointments[sortedAppointments.length - 1];
            
            lastAppointmentEnd = lastAppointment.end;
            lastAppointmentNotes = lastAppointment.notes || "";
        } else {
             return { success: false, message: "Randevu grubu bulunamadı." };
        }
        
        const newAppointmentStart = lastAppointmentEnd;
        const newAppointmentEnd = new Date(newAppointmentStart.getTime() + duration * 60000);

        const appointmentData = {
            groupId,
            customerId,
            customerName: customerDoc.data()?.fullName,
            personnelId,
            personnelName: personnelDoc.data()?.fullName,
            serviceId,
            serviceName: serviceOrPackageDoc.data()?.name,
            price,
            isPackage,
            isPackageSession: false, 
            start: Timestamp.fromDate(newAppointmentStart),
            end: Timestamp.fromDate(newAppointmentEnd),
            notes: lastAppointmentNotes,
            createdAt: FieldValue.serverTimestamp(),
            status: "active",
        };

        await db.collection("appointments").add(appointmentData);

        revalidatePath("/takvim");
        return { success: true };

    } catch (error: any) {
        console.error("Randevuya hizmet eklenirken hata:", error);
        return { success: false, message: error.message || "Hizmet eklenemedi." };
    }
}

export async function updateAppointmentServicePriceAction(appointmentId: string, newPrice: number) {
    'use server';
    if (!appointmentId || typeof newPrice !== 'number' || newPrice < 0) {
        return { success: false, message: "Geçersiz veri." };
    }
    if (!db) return { success: false, message: "Veritabanı bağlantı hatası." };
    
    try {
        const appointmentRef = db.collection("appointments").doc(appointmentId);
        await appointmentRef.update({ price: newPrice });
        
        revalidatePath("/takvim");
        return { success: true, message: "Fiyat güncellendi." };
    } catch (error: any) {
        console.error("Randevu fiyatı güncellenirken hata:", error);
        return { success: false, message: "Fiyat güncellenemedi." };
    }
}
