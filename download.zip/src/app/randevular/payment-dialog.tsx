

"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useState, useMemo, useEffect } from "react";
import type { CalendarEvent } from "../takvim/page";
import { formatCurrency } from "@/lib/utils";
import { Separator } from "@/components/ui/separator";
import { performPaymentAndUseSessionAction, type PaymentMethod, type Appointment } from "./actions";
import { Badge } from "@/components/ui/badge";

interface ServiceLine {
    price: string;
    name: string;
    isPackageSession: boolean;
}

interface SaleLine {
    totalAmount: number;
    name: string;
}

interface PaymentDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  appointmentGroup: Appointment[];
  saleLines: SaleLine[];
  onSuccess?: () => void;
}

export function PaymentDialog({
  isOpen,
  onOpenChange,
  appointmentGroup,
  saleLines,
  onSuccess,
}: PaymentDialogProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("Nakit");

  const firstAppointment = appointmentGroup[0];

  useEffect(() => {
    if (isOpen) {
        setPaymentMethod("Nakit");
        setIsSubmitting(false);
    }
  }, [isOpen]);

  const serviceLines = useMemo(() => {
    return appointmentGroup.map(app => ({
      price: String(app.price),
      name: app.serviceName,
      isPackageSession: app.isPackageSession
    }));
  }, [appointmentGroup]);

  const totalServiceAmount = useMemo(() => {
    return serviceLines.filter(line => !line.isPackageSession).reduce((sum, line) => sum + (parseFloat(line.price) || 0), 0);
  }, [serviceLines]);

  const totalProductAmount = useMemo(() => {
    return saleLines.reduce((sum, line) => sum + line.totalAmount, 0);
  }, [saleLines]);
  
  const hasPackageSession = useMemo(() => serviceLines.some(line => line.isPackageSession), [serviceLines]);
  const grandTotalAmount = totalServiceAmount + totalProductAmount;

  const handlePayment = async () => {
    if (!paymentMethod && grandTotalAmount > 0) {
      toast({
        title: "Hata",
        description: "Lütfen bir ödeme yöntemi seçin.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const result = await performPaymentAndUseSessionAction({
        groupId: firstAppointment.groupId,
        customerId: firstAppointment.customerId,
        customerName: firstAppointment.customerName,
        totalServiceAmount,
        totalProductAmount,
        grandTotalAmount,
        paymentMethod: paymentMethod || 'Nakit', // Fallback for 0 amount payments
        appointmentsInGroup: appointmentGroup,
      });

      if (result.success) {
        toast({
          title: "Ödeme Başarılı",
          description: "İşlem başarıyla kaydedildi.",
        });
        onSuccess?.();
        onOpenChange(false);
      } else {
        toast({
          title: "Ödeme Hatası",
          description: result.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Sunucu Hatası",
        description: "Ödeme işlemi sırasında bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (!firstAppointment) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg bg-card p-0 rounded-xl shadow-lg" hideCloseButton={true}>
        <div className="p-6">
            <DialogTitle className="text-lg font-semibold text-center">Ödeme ve Onay Ekranı</DialogTitle>
            <DialogDescription className="text-sm text-center text-muted-foreground -mt-1">
                Müşteri: {firstAppointment.customerName}
            </DialogDescription>
        </div>

        <div className="px-6 space-y-4 max-h-80 overflow-y-auto">
          {serviceLines.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Hizmetler</h4>
              <div className="space-y-1">
                {serviceLines.map((line, index) => (
                  <div key={`service-${index}`} className="flex justify-between">
                    <span>{line.name}</span>
                    <span>{line.isPackageSession ? <Badge variant="secondary">Paket Kullanımı</Badge> : formatCurrency(parseFloat(line.price) || 0)}</span>
                  </div>
                ))}
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between font-semibold">
                <span>Hizmet Ara Toplamı</span>
                <span>{formatCurrency(totalServiceAmount)}</span>
              </div>
            </div>
          )}

          {saleLines.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Ürünler</h4>
              <div className="space-y-1">
                {saleLines.map((line, index) => (
                  <div key={`sale-${index}`} className="flex justify-between">
                    <span>{line.name}</span>
                    <span>{formatCurrency(line.totalAmount)}</span>
                  </div>
                ))}
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between font-semibold">
                <span>Ürün Ara Toplamı</span>
                <span>{formatCurrency(totalProductAmount)}</span>
              </div>
            </div>
          )}
          
          <div className="p-4 bg-secondary rounded-lg">
             <div className="flex justify-between text-lg font-bold">
                <span>GENEL TOPLAM</span>
                <span>{formatCurrency(grandTotalAmount)}</span>
            </div>
          </div>


          {grandTotalAmount > 0 && (
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-3">Ödeme Yöntemi</h4>
              <RadioGroup
                value={paymentMethod}
                onValueChange={(value) => setPaymentMethod(value as PaymentMethod)}
                className="grid grid-cols-3 gap-4"
                disabled={isSubmitting}
              >
                <div>
                  <RadioGroupItem value="Nakit" id="nakit" className="peer sr-only" />
                  <Label
                    htmlFor="nakit"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    Nakit
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="Kart" id="kart" className="peer sr-only" />
                  <Label
                    htmlFor="kart"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    Kart
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="Havale/EFT" id="havale" className="peer sr-only" />
                  <Label
                    htmlFor="havale"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    Havale/EFT
                  </Label>
                </div>
              </RadioGroup>
            </div>
          )}
        </div>
        <DialogFooter className="px-6 py-4 border-t bg-secondary rounded-b-xl">
          <Button
            type="button"
            className="w-full bg-green-600 hover:bg-green-700 text-white"
            onClick={handlePayment}
            disabled={isSubmitting || (!paymentMethod && grandTotalAmount > 0)}
          >
            {isSubmitting ? "İşleniyor..." : (hasPackageSession ? "Kullanım Düş ve Kapat" : "Ödemeyi Al ve Kapat")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
