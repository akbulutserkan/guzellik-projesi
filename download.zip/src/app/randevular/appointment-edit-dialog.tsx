
"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Combobox } from "@/components/ui/combobox";
import { useToast } from "@/hooks/use-toast";
import { useState, type FormEvent, type ReactNode, useMemo, useEffect, useRef } from "react";
import { 
    performFullUpdateAppointmentAction, 
    performDeleteAppointmentAction, 
    performPaymentAndUseSessionAction, 
    addServiceToAppointmentAction, 
    deleteSingleAppointmentAction,
    updateAppointmentServicePriceAction,
    type PaymentMethod, 
    type Appointment, 
    getSalesForAppointmentGroupAction 
} from "./actions";
import type { Customer } from "../musteriler/actions";
import { CustomerDialog } from "../musteriler/customer-dialog";
import type { Personel } from "../personeller/actions";
import type { Service } from "../hizmetler/actions";
import type { Package } from "../paketler/actions";
import { Plus, Wallet, User, BadgeCent, PlusCircle, RotateCw, X, Edit, Trash2 } from "lucide-react";
import { cn, formatCurrency, formatPhoneNumber } from "@/lib/utils";
import { format } from "date-fns";
import { tr } from 'date-fns/locale';
import { Input } from "@/components/ui/input";
import type { CalendarEvent } from "../takvim/page";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent as AlertContent,
  AlertDialogDescription as AlertDescription,
  AlertDialogFooter as AlertFooter,
  AlertDialogHeader as AlertHeader,
  AlertDialogTitle as AlertTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Separator } from "@/components/ui/separator";
import { Product as SaleableProduct, Sale } from "../urun-satislar/actions";
import { getProductDetailsAction } from "../urunler/actions";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CustomTimePicker } from "@/components/ui/custom-time-picker";


interface ServiceLine {
    id: string; 
    personnelId: string;
    serviceId: string;
    price: string;
    name: string; 
    isPackageSession: boolean;
    packageSaleId?: string;
    isNew?: boolean;
}

interface SaleLine {
    id: number; 
    productId: string;
    quantity: number;
    totalAmount: number;
    personnelId: string;
    productDetails?: { stock: number; sellingPrice: number } | null;
    name: string; 
}

interface AppointmentEditDialogProps {
  appointment: CalendarEvent;
  allAppointments: CalendarEvent[];
  customers: Customer[];
  personnelList: Personel[];
  services: Service[];
  packages: Package[];
  products: SaleableProduct[];
  onFullSuccess?: () => void;
  onPartialSuccess?: (newCustomer?: Customer) => void;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AppointmentEditDialog({ 
    appointment, 
    allAppointments,
    customers, 
    personnelList, 
    services, 
    packages, 
    products,
    onFullSuccess,
    onPartialSuccess,
    isOpen, 
    onOpenChange, 
}: AppointmentEditDialogProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  
  // Current state
  const [serviceLines, setServiceLines] = useState<ServiceLine[]>([]);
  const [saleLines, setSaleLines] = useState<SaleLine[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [date, setDate] = useState<Date | undefined>();
  const [startTime, setStartTime] = useState("10:00");
  const [notes, setNotes] = useState("");
  
  // States for calculated values to drive the UI
  const [totalPaidAmount, setTotalPaidAmount] = useState(0);
  const [hasPackageSession, setHasPackageSession] = useState(false);
  
  const [allGroupIds, setAllGroupIds] = useState<string[]>([]);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [appointmentsInGroup, setAppointmentsInGroup] = useState<Appointment[]>([]);
  const [focusedLineId, setFocusedLineId] = useState<string | number | null>(null);
  const [servicesDirty, setServicesDirty] = useState(false);
  
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);

  const personnelOptions = useMemo(() => personnelList.map(p => ({ value: p.id, label: p.fullName })), [personnelList]);
  const serviceAndPackageOptions = useMemo(() => {
    const serviceOpts = services.map(s => ({ value: s.id, label: s.name, price: s.price }));
    const packageOpts = packages.map(p => ({ value: p.id, label: `Paket: ${p.name}`, price: p.price }));
    return [...serviceOpts, ...packageOpts];
  }, [services, packages]);

  const productOptions = useMemo(() => 
    products.map(p => ({ value: p.id, label: `${p.name} (Stok: ${p.stock})`})), 
  [products]);

  // Populate form when dialog opens
  useEffect(() => {
    const initializeDialog = async () => {
        if (isOpen && appointment) {
            setServicesDirty(false); // Reset dirty check on open
            const dayAppointments = allAppointments
            .filter(a => a.groupId === appointment.groupId)
            .sort((a, b) => a.start.getTime() - b.start.getTime());

            const uniqueGroupIds = [...new Set(dayAppointments.map(a => a.groupId))];
            const salesForGroup = await getSalesForAppointmentGroupAction(uniqueGroupIds);


            const servicesData = dayAppointments.map(app => ({
                id: app.id,
                personnelId: app.personnelId,
                serviceId: app.serviceId,
                price: app.isPackageSession ? '0' : String(app.price),
                name: app.serviceName,
                isPackageSession: app.isPackageSession || false,
                packageSaleId: app.packageSaleId,
            }));
            
            const salesData = salesForGroup.map((sale: Sale, index: number) => ({
                id: Date.now() + index,
                productId: sale.productId,
                quantity: sale.quantity,
                totalAmount: sale.totalAmount,
                personnelId: sale.personnelId || "",
                productDetails: { stock: products.find(p=>p.id === sale.productId)?.stock || 0, sellingPrice: sale.totalAmount / sale.quantity },
                name: sale.productName,
            }));
            
            recalculateTotals(servicesData, salesData);

            if (dayAppointments.length > 0) {
                const firstAppointment = dayAppointments[0];
                const customerId = firstAppointment.customerId;
                const customer = customers.find(c => c.id === customerId);
                
                setSelectedCustomerId(customerId);
                setCustomerName(customer ? customer.fullName : firstAppointment.customerName);
                setCustomerPhone(customer ? customer.phone : "");

                setDate(firstAppointment.start);
                setStartTime(format(firstAppointment.start, 'HH:mm'));
                setNotes(firstAppointment.notes || "");
                setAllGroupIds(uniqueGroupIds);
            }

            setAppointmentsInGroup(dayAppointments as Appointment[]);
            setServiceLines(servicesData);
            setSaleLines(salesData);
            setFocusedLineId(null);
        }
    };
    initializeDialog();
  }, [isOpen, appointment, allAppointments, products, customers]);


  const isDirty = useMemo(() => {
    // This function can be improved, but for now, any change will enable the save button.
    // A more robust check would compare initial state with current state.
    return true; 
  }, [serviceLines, saleLines, date, startTime, notes, selectedCustomerId]);
  
  const recalculateTotals = (updatedServiceLines: ServiceLine[], updatedSaleLines: SaleLine[]) => {
    const localHasPackageSession = updatedServiceLines.some(l => l.isPackageSession);
    const localTotalPaidAmount = updatedServiceLines
        .filter(l => !l.isPackageSession)
        .reduce((sum, currentLine) => sum + (parseFloat(currentLine.price) || 0), 0)
        +
        updatedSaleLines.reduce((sum, saleLine) => sum + saleLine.totalAmount, 0);

    setHasPackageSession(localHasPackageSession);
    setTotalPaidAmount(localTotalPaidAmount);
  };

  const handlePriceBlur = async (appointmentId: string, newPrice: string) => {
    const numericPrice = parseFloat(newPrice);
    if (isNaN(numericPrice)) return;
    
    setIsSubmitting(true);
    const result = await updateAppointmentServicePriceAction(appointmentId, numericPrice);
    setIsSubmitting(false);

    if (result.success) {
      toast({
        title: "Fiyat Güncellendi",
        description: `Değişiklik başarıyla kaydedildi.`,
      });
      onPartialSuccess?.(); // Re-fetch data to reflect the change
    } else {
      toast({
        title: "Hata",
        description: result.message,
        variant: "destructive",
      });
    }
  };

 const updateServiceLine = async (index: number, field: keyof Omit<ServiceLine, 'id'| 'name' | 'isPackageSession' | 'packageSaleId' | 'isNew'>, value: string) => {
    const newLines = [...serviceLines];
    const line = { ...newLines[index] };
    const isNewLine = line.isNew;
    (line as any)[field] = value;
    
    if (field === 'serviceId') {
        const selected = serviceAndPackageOptions.find(opt => opt.value === line.serviceId);
        if (selected) {
            line.price = String(selected.price);
        }
    }

    newLines[index] = line;
    setServiceLines(newLines);
    recalculateTotals(newLines, saleLines);

    if (isNewLine && field === 'serviceId' && line.personnelId && line.serviceId) {
        setIsSubmitting(true);
        const selectedOption = serviceAndPackageOptions.find(opt => opt.value === line.serviceId);
        
        const result = await addServiceToAppointmentAction({
            groupId: appointment.groupId,
            customerId: selectedCustomerId,
            personnelId: line.personnelId,
            serviceId: line.serviceId,
            price: selectedOption?.price ?? 0,
            isPackage: !!selectedOption?.label.startsWith('Paket:'),
        });

        if (result.success) {
            toast({ title: "Başarılı", description: "Hizmet başarıyla eklendi." });
            onPartialSuccess?.(); // Sadece veriyi yeniler, modalı kapatmaz
        } else {
            toast({ title: "Hata", description: result.message, variant: "destructive" });
            setServiceLines(prev => prev.filter(l => l.id !== line.id));
        }
        setIsSubmitting(false);
    }
  };

  const addServiceLine = () => {
    setServicesDirty(true);
    setServiceLines([...serviceLines, { id: `new_${Date.now()}`, personnelId: "", serviceId: "", price: "", name: "", isPackageSession: false, isNew: true }]);
  }

 const removeServiceLine = async (lineId: string, index: number) => {
    setServicesDirty(true);
    const lineToRemove = serviceLines[index];
    // Do not try to delete a line that hasn't been saved yet
    if (lineToRemove.isNew) {
        const updatedLines = serviceLines.filter((_, i) => i !== index);
        setServiceLines(updatedLines);
        recalculateTotals(updatedLines, saleLines);
        return;
    }
    
    setIsSubmitting(true);
    const result = await deleteSingleAppointmentAction(lineId);
    if (result.success) {
      toast({ title: "Başarılı", description: "Hizmet başarıyla silindi." });
      onPartialSuccess?.(); // Veriyi yenile, modalı açık tut
    } else {
      toast({ title: "Hata", description: result.message, variant: "destructive" });
    }
    setIsSubmitting(false);
  };

  const addSaleLine = () => setSaleLines([...saleLines, { id: Date.now(), productId: "", quantity: 1, totalAmount: 0, personnelId: "", productDetails: null, name: "" }]);
  
  const updateSaleLine = (index: number, field: keyof Omit<SaleLine, 'id' | 'productDetails' | 'name'>, value: string | number) => {
    const newLines = [...saleLines];
    const lineToUpdate = newLines[index];
    if (!lineToUpdate) return;
  
    (lineToUpdate as any)[field] = value;
  
    if (field === 'productId') {
      getProductDetailsAction(value as string).then(details => {
        setSaleLines(prevLines => {
          const updatedLines = [...prevLines];
          const currentLine = updatedLines[index];
          if (currentLine) {
            currentLine.productDetails = details;
            const selectedProduct = products.find(p => p.id === value);
            currentLine.name = selectedProduct?.name || "";
            if (details) {
              currentLine.quantity = 1;
              currentLine.totalAmount = details.sellingPrice;
            } else {
              currentLine.totalAmount = 0;
            }
          }
          recalculateTotals(serviceLines, updatedLines);
          return updatedLines;
        });
      });
    } else if (field === 'quantity' && lineToUpdate.productDetails) {
      const quantity = Number(value) || 0;
      lineToUpdate.totalAmount = quantity * lineToUpdate.productDetails.sellingPrice;
    }
  
    setSaleLines(newLines);
    recalculateTotals(serviceLines, newLines);
  };
  
  const handleTotalAmountBlur = (index: number) => {
    recalculateTotals(serviceLines, saleLines);
  };


  const removeSaleLine = (index: number) => {
    const updatedLines = saleLines.filter((_, i) => i !== index);
    setSaleLines(updatedLines);
    recalculateTotals(serviceLines, updatedLines);
    setFocusedLineId(null);
  };

  const handlePaymentOrUsage = async (paymentMethod: PaymentMethod | null) => {
    setIsSubmitting(true);

    const customer = customers.find(c => c.id === selectedCustomerId);
    if (!customer) {
        toast({ title: "Hata", description: "Müşteri bulunamadı.", variant: "destructive"});
        setIsSubmitting(false);
        return;
    }
    
    try {
        const payload = {
            groupId: appointment.groupId,
            customerId: customer.id,
            customerName: customer.fullName,
            totalServiceAmount: serviceLines.filter(l => !l.isPackageSession).reduce((sum, line) => sum + (parseFloat(line.price) || 0), 0),
            totalProductAmount: saleLines.reduce((sum, line) => sum + line.totalAmount, 0),
            grandTotalAmount: totalPaidAmount,
            paymentMethod: paymentMethod || 'Nakit', // Fallback for 0 amount payments
            appointmentsInGroup: appointmentsInGroup,
        };
        
        const result = await performPaymentAndUseSessionAction(payload);

        if (result.success) {
            toast({ title: "Başarılı", description: result.message });
            onFullSuccess?.();
        } else {
            toast({ title: "Hata", description: result.message, variant: "destructive" });
        }
    } catch (error: any) {
        toast({ title: "Sunucu Hatası", description: error.message || "İşlem sırasında bir hata oluştu.", variant: "destructive" });
    } finally {
        setIsSubmitting(false);
    }
  };


  const handleFormSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsSubmitting(true);

    const formData = new FormData();
    formData.append("groupId", appointment.groupId);
    formData.append("allGroupIdsToDelete", allGroupIds.join(','));
    formData.append("customerId", selectedCustomerId);
    formData.append("isDurationChanged", String(servicesDirty));
    
    if (date && startTime) {
      const dateString = format(date, "yyyy-MM-dd");
      const fullDate = new Date(`${dateString}T${startTime}`);
      formData.append("dateTime", fullDate.toISOString());
    }
    
    formData.append("notes", notes);
    
    serviceLines.forEach(line => {
        if(line.personnelId && line.serviceId){
            formData.append("personnelIds", line.personnelId);
            formData.append("serviceOrPackageIds", line.serviceId);
            formData.append("prices", line.price);
            formData.append("isPackageSession", String(line.isPackageSession));
            if (line.packageSaleId) {
                formData.append("packageSaleIds", line.packageSaleId);
            } else {
                formData.append("packageSaleIds", "");
            }
        }
    });
    
    saleLines.forEach(line => {
        if (line.productId && line.quantity > 0 && line.personnelId) {
            formData.append("soldProductIds", line.productId);
            formData.append("soldQuantities", String(line.quantity));
            formData.append("soldTotalAmounts", String(line.totalAmount));
            formData.append("soldPersonnelIds", line.personnelId);
        }
    });
    
    try {
      const result = await performFullUpdateAppointmentAction(formData);

      if (result.success) {
        toast({ title: "Başarılı", description: result.message });
        onFullSuccess?.();
      } else {
        toast({ title: "Hata", description: result.message, variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Hata", description: "Beklenmedik bir sunucu hatası oluştu.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      for (const groupId of allGroupIds) {
        await performDeleteAppointmentAction(groupId);
      }
      toast({ title: "Başarılı", description: "Randevu başarıyla iptal edildi." });
      
      onFullSuccess?.();

    } catch (error) {
      toast({ title: "Hata", description: "Randevu iptal edilirken bir hata oluştu.", variant: "destructive" });
    } finally {
      setIsDeleting(false);
    }
  };
   const handleNewCustomerSuccess = (newCustomer?: Customer) => {
      if(newCustomer){
        onPartialSuccess?.(newCustomer);
        setSelectedCustomerId(newCustomer.id);
        setIsAddCustomerOpen(false);
      }
  }


  const isFormValid = useMemo(() => {
      const servicesValid = serviceLines.length > 0 && serviceLines.every(line => line.personnelId && line.serviceId);
      const salesValid = saleLines.every(line => line.productId && line.quantity > 0 && line.personnelId && line.quantity <= (line.productDetails?.stock || 0));
      return selectedCustomerId && servicesValid && salesValid;
  }, [selectedCustomerId, serviceLines, saleLines]);

  const renderPaymentButton = () => {
    const isCompleted = appointment.status === 'completed';
    const allLinesArePackages = serviceLines.length > 0 && serviceLines.every(line => line.isPackageSession);
  
    if (allLinesArePackages && saleLines.length === 0) {
      return (
        <Button
          type="button"
          className="bg-green-700 hover:bg-green-800 text-white w-full h-10 text-sm"
          disabled={isSubmitting || isDeleting || !isFormValid || isCompleted}
          onClick={() => handlePaymentOrUsage(null)}
        >
          <span className="font-semibold">Kullanım Düş ve Kapat</span>
        </Button>
      );
    }
  
    if (totalPaidAmount > 0) {
        const buttonText = hasPackageSession
          ? `${formatCurrency(totalPaidAmount)} Öde, Kullanım Düş ve Kapat`
          : `${formatCurrency(totalPaidAmount)} Ödeme Al ve Kapat`;
  
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              className="bg-green-700 hover:bg-green-800 text-white w-full h-10 text-sm"
              disabled={isSubmitting || isDeleting || !isFormValid || isCompleted}
            >
                <span className="font-semibold">
                    {buttonText}
                </span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent 
              className="w-[--radix-dropdown-menu-trigger-width] bg-card rounded-xl shadow-xl border p-0"
            >
              <DropdownMenuItem onSelect={() => handlePaymentOrUsage("Nakit")} className="justify-center px-4 py-3 cursor-pointer hover:bg-muted rounded-t-xl transition">
                  <span className="font-semibold">Nakit</span>
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => handlePaymentOrUsage("Kart")} className="justify-center px-4 py-3 cursor-pointer hover:bg-muted transition">
                  <span className="font-semibold">Kart</span>
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => handlePaymentOrUsage("Havale/EFT")} className="justify-center px-4 py-3 cursor-pointer hover:bg-muted rounded-b-xl transition">
                 <span className="font-semibold">Havale / EFT</span>
              </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    }
  
    if (totalPaidAmount === 0 && !hasPackageSession && serviceLines.length > 0) {
       return (
        <Button
          type="button"
          className="bg-green-700 hover:bg-green-800 text-white w-full h-10 text-sm"
          disabled={isSubmitting || isDeleting || !isFormValid || isCompleted}
          onClick={() => handlePaymentOrUsage(null)}
        >
          <span className="font-semibold">Randevuyu Kapat</span>
        </Button>
      );
    }

    if (totalPaidAmount > 0 && allLinesArePackages && saleLines.length > 0) {
        return (
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button type="button" className="bg-green-700 hover:bg-green-800 text-white w-full h-10 text-sm font-semibold" disabled={isSubmitting || isDeleting || !isFormValid || isCompleted}>
                        {`${formatCurrency(totalPaidAmount)} Ödeme Al, Kullanım Düş ve Kapat`}
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent 
                  className="w-[--radix-dropdown-menu-trigger-width] bg-card rounded-xl shadow-xl border p-0"
                >
                    <DropdownMenuItem onSelect={() => handlePaymentOrUsage("Nakit")} className="justify-center px-4 py-3 cursor-pointer hover:bg-muted rounded-t-xl transition">
                       <span className="font-semibold">Nakit</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onSelect={() => handlePaymentOrUsage("Kart")} className="justify-center px-4 py-3 cursor-pointer hover:bg-muted transition">
                        <span className="font-semibold">Kart</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onSelect={() => handlePaymentOrUsage("Havale/EFT")} className="justify-center px-4 py-3 cursor-pointer hover:bg-muted rounded-b-xl transition">
                        <span className="font-semibold">Havale / EFT</span>
                    </DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
        );
    }


    return <Button type="button" className="bg-muted w-full h-10" disabled>Kapat</Button>;
  };

  return (
    <>
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl p-0 flex flex-col rounded-xl shadow-lg h-full max-h-[95vh]">
        <form onSubmit={handleFormSubmit} className="flex flex-col h-full flex-grow min-h-0">
            {/* Header */}
            <div className="p-4 pb-2 flex-shrink-0">
                 <div className="flex items-center justify-between gap-3">
                    <div className="flex-grow">
                        <DialogTitle className="text-lg font-bold">{customerName}</DialogTitle>
                        <DialogDescription className="text-sm text-muted-foreground">{formatPhoneNumber(customerPhone)}</DialogDescription>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="outline" size="icon" className="h-10 w-10 rounded-lg flex-shrink-0 bg-card shadow-md">
                                <Plus className="h-5 w-5" /> 
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                                <DropdownMenuItem onSelect={addServiceLine} disabled={isSubmitting || isDeleting}>Hizmet Ekle</DropdownMenuItem>
                                <DropdownMenuItem onSelect={addSaleLine} disabled={isSubmitting || isDeleting}>Ürün Ekle</DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>
                        <Popover>
                            <PopoverTrigger asChild>
                                <button type="button" className="flex flex-col items-center justify-center text-center w-14 h-14 cursor-pointer rounded-full hover:bg-accent transition-colors group border shadow-md">
                                    <span className="text-xs font-semibold uppercase text-muted-foreground group-hover:text-primary">
                                        {date ? format(date, 'EEE', { locale: tr }) : ''}
                                    </span>
                                    <span className="text-xl font-bold text-primary">
                                        {date ? format(date, 'd') : ''}
                                    </span>
                                </button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                                <Calendar
                                    mode="single"
                                    selected={date}
                                    onSelect={setDate}
                                    initialFocus
                                    locale={tr}
                                    captionLayout="dropdown-buttons"
                                    fromYear={2020}
                                    toYear={new Date().getFullYear() + 1}
                                />
                            </PopoverContent>
                        </Popover>
                        <CustomTimePicker
                            value={startTime}
                            onChange={setStartTime}
                            disabled={isSubmitting || isDeleting}
                        />
                    </div>
                 </div>
            </div>

            {/* Content */}
            <div className="p-6 pt-2 space-y-2 flex-grow overflow-y-auto max-h-[calc(100vh-250px)]">
                {serviceLines.map((line, index) => (
                    <div 
                    key={line.id} 
                    className="grid grid-cols-12 gap-2 items-center"
                    >
                        <div className="col-span-4">
                            <Combobox options={personnelOptions} value={line.personnelId} onChange={(value) => updateServiceLine(index, 'personnelId', value)} placeholder="Personel seçin..." searchPlaceholder="Personel ara..." disabled={isSubmitting || isDeleting} />
                        </div>
                        <div className="col-span-4">
                            <Combobox options={serviceAndPackageOptions} value={line.serviceId} onChange={(value) => updateServiceLine(index, 'serviceId', value)} placeholder="Hizmet veya Paket..." searchPlaceholder="Hizmet/Paket ara..." disabled={isSubmitting || isDeleting || !line.personnelId}/>
                        </div>
                        
                        <div className="col-span-3">
                        {line.isPackageSession ? (
                            <div className="flex items-center justify-center h-10">
                                <Badge variant="secondary" className="h-10 text-sm w-full justify-center">
                                    <BadgeCent className="mr-2 h-4 w-4"/>
                                    Paket
                                </Badge>
                            </div>
                        ) : (
                            <div className="relative flex items-center h-10">
                                <Input
                                    type="number"
                                    defaultValue={line.price}
                                    onBlur={(e) => handlePriceBlur(line.id, e.target.value)}
                                    placeholder="Fiyat"
                                    className="h-10 w-full rounded-md shadow-md pl-2 pr-6"
                                    required
                                    disabled={isSubmitting || isDeleting || !line.serviceId}
                                    step="0.01"
                                    min="0"
                                />
                                <span className="absolute inset-y-0 right-1.5 flex items-center text-xs text-muted-foreground pointer-events-none">₺</span>
                            </div>
                        )}
                        </div>

                        <div className="col-span-1 flex justify-end">
                            {serviceLines.length > 0 && (
                                <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <Button type="button" variant="ghost" size="icon" className="text-destructive hover:text-destructive h-8 w-8" disabled={isSubmitting || isDeleting}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </AlertDialogTrigger>
                                    <AlertContent>
                                        <AlertHeader>
                                            <AlertTitle>Bu Hizmeti Silmek İstediğinize Emin misiniz?</AlertTitle>
                                            <AlertDescription>
                                                Bu işlem geri alınamaz. Bu hizmet randevudan kalıcı olarak kaldırılacaktır.
                                            </AlertDescription>
                                        </AlertHeader>
                                        <AlertFooter>
                                            <AlertDialogCancel>Vazgeç</AlertDialogCancel>
                                            <AlertDialogAction onClick={() => removeServiceLine(line.id, index)}>Evet, Sil</AlertDialogAction>
                                        </AlertFooter>
                                    </AlertContent>
                                </AlertDialog>
                            )}
                        </div>
                    </div>
                ))}
            
                {saleLines.map((line, index) => (
                    <div 
                    key={line.id} 
                    className="p-1 border rounded-md mt-2"
                    >
                        <div className="grid grid-cols-12 gap-2 items-center">
                            <div className="col-span-6">
                                <Combobox options={productOptions} value={line.productId} onChange={(value) => updateSaleLine(index, 'productId', value)} placeholder="Ürün seçin..." searchPlaceholder="Ürün ara..." disabled={isSubmitting || isDeleting}/>
                            </div>
                            <div className="col-span-2">
                                <div className="relative flex items-center rounded-md shadow-md focus-within:ring-2 focus-within:ring-ring bg-card h-10">
                                    <Input type="number" value={line.quantity} onChange={(e) => updateSaleLine(index, 'quantity', parseInt(e.target.value) || 1)} className="flex-1 border-0 focus-visible:ring-0 focus-visible:ring-offset-0 rounded-lg pl-2 h-full pr-12" disabled={isSubmitting || isDeleting || !line.productId} min="1" max={line.productDetails?.stock}/>
                                    <span className="absolute inset-y-0 right-3 flex items-center text-xs text-muted-foreground pointer-events-none">Adet</span>
                                </div>
                            </div>
                            <div className="col-span-3">
                                <div className="relative flex items-center rounded-md shadow-md focus-within:ring-2 focus-within:ring-ring bg-card h-10">
                                    <Input id="totalAmount" name="totalAmount" type="number" defaultValue={line.totalAmount} onBlur={() => handleTotalAmountBlur(index)} onChange={(e) => updateSaleLine(index, 'totalAmount', parseFloat(e.target.value) || 0)} placeholder="Tutar" className="flex-1 border-0 focus-visible:ring-0 focus-visible:ring-offset-0 rounded-lg pl-2 h-full pr-8" step="0.01" min="0" required disabled={isSubmitting || isDeleting || !line.productId} />
                                    <span className="absolute inset-y-0 right-3 flex items-center text-muted-foreground pointer-events-none">₺</span>
                                </div>
                            </div>
                            <div className="col-span-1 flex justify-end">
                                <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <Button type="button" variant="ghost" size="icon" className="text-destructive hover:text-destructive h-8 w-8" disabled={isSubmitting || isDeleting}>
                                            <X className="h-4 w-4" />
                                        </Button>
                                    </AlertDialogTrigger>
                                    <AlertContent>
                                        <AlertHeader>
                                            <AlertTitle>Bu Ürün Satışını Silmek İstediğinize Emin misiniz?</AlertTitle>
                                            <AlertDescription>
                                                Bu işlem geri alınamaz. Bu ürün satışı randevudan kaldırılacaktır.
                                            </AlertDescription>
                                        </AlertHeader>
                                        <AlertFooter>
                                            <AlertDialogCancel>Vazgeç</AlertDialogCancel>
                                            <AlertDialogAction onClick={() => removeSaleLine(index)}>Evet, Sil</AlertDialogAction>
                                        </AlertFooter>
                                    </AlertContent>
                                </AlertDialog>
                            </div>
                        </div>
                        <Combobox 
                            options={personnelOptions} 
                            value={line.personnelId} 
                            onChange={(value) => updateSaleLine(index, 'personnelId', value)} 
                            placeholder="Satışı yapan personeli seçin..." 
                            searchPlaceholder="Personel ara..." 
                            disabled={isSubmitting || isDeleting || !line.productId}
                        />
                    </div>
                ))}
                <div className="relative flex items-center rounded-md shadow-md h-9 mt-1">
                    <Input id="notes" name="notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Notlar..." className="w-full h-full border-0 bg-card focus-visible:ring-0 focus-visible:ring-offset-0 pl-3 pr-3 text-sm font-bold text-destructive placeholder:text-muted-foreground" disabled={isSubmitting || isDeleting} />
                </div>
            </div>
            
            <DialogFooter className="p-3 mt-auto border-t bg-secondary flex-shrink-0">
                <div className="flex w-full items-center gap-2">
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                             <Button type="button" variant="destructive" size="icon" className="h-10 w-10" disabled={isSubmitting || isDeleting}>
                                <Trash2 className="h-4 w-4" />
                             </Button>
                        </AlertDialogTrigger>
                        <AlertContent>
                            <AlertHeader>
                                <AlertTitle>Bu Randevuyu İptal Etmek İstediğinize Emin misiniz?</AlertTitle>
                                <AlertDescription>
                                    Bu müşterinin bu randevusunu ve varsa ilişkili ürün satışlarını kalıcı olarak iptal edecektir.
                                </AlertDescription>
                            </AlertHeader>
                            <AlertFooter>
                                <AlertDialogCancel>Vazgeç</AlertDialogCancel>
                                <AlertDialogAction onClick={handleDelete} disabled={isDeleting} className="bg-destructive hover:bg-destructive/90">
                                    {isDeleting ? "İptal Ediliyor..." : "Evet, İptal Et"}
                                </AlertDialogAction>
                            </AlertFooter>
                        </AlertContent>
                    </AlertDialog>
                    <Button type="submit" size="icon" className="h-10 w-10 bg-blue-600 hover:bg-blue-700 text-white" disabled={isSubmitting || isDeleting || !isDirty || appointment.status === 'completed'}>
                        {isSubmitting ? <RotateCw className="h-4 w-4 animate-spin" /> : <Edit className="h-4 w-4" />}
                    </Button>
                    <div className="flex-grow">
                        {renderPaymentButton()}
                    </div>
                </div>
            </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
     <CustomerDialog
        isOpen={isAddCustomerOpen}
        onOpenChange={setIsAddCustomerOpen}
        onSuccess={handleNewCustomerSuccess}
        initialName={customerSearchQuery}
      >
        <div style={{ display: 'none' }} />
      </CustomerDialog>
    </>
  );
}
